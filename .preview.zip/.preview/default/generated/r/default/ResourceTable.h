/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef RESOURCE_TABLE_H
#define RESOURCE_TABLE_H

#include<stdint.h>

namespace OHOS {
const int32_t STRING_APP_DESC = 0x01000037;
const int32_t STRING_APP_NAME = 0x01000003;
const int32_t STRING_INTERNET_PERMISSION_REASON = 0x01000034;
const int32_t STRING_MODULE_DESC = 0x01000013;
const int32_t COLOR_START_WINDOW_BACKGROUND = 0x0100000b;
const int32_t FLOAT_PAGE_TEXT_FONT_SIZE = 0x01000027;
const int32_t MEDIA_ADD = 0x01000023;
const int32_t MEDIA_AVARTER = 0x0100001b;
const int32_t MEDIA_BACKGROUND = 0x01000001;
const int32_t MEDIA_BBG = 0x01000029;
const int32_t MEDIA_BG = 0x0100002d;
const int32_t MEDIA_BG1 = 0x01000019;
const int32_t MEDIA_BG2 = 0x0100001c;
const int32_t MEDIA_BG3 = 0x01000007;
const int32_t MEDIA_BG4 = 0x01000028;
const int32_t MEDIA_BK = 0x01000010;
const int32_t MEDIA_CET_NEWS = 0x01000022;
const int32_t MEDIA_CHECK = 0x0100000f;
const int32_t MEDIA_CLOSE = 0x0100001a;
const int32_t MEDIA_DELETE = 0x0100001e;
const int32_t MEDIA_EDIT = 0x01000018;
const int32_t MEDIA_EMO = 0x01000026;
const int32_t MEDIA_EMOBG = 0x01000016;
const int32_t MEDIA_FOREGROUND = 0x01000000;
const int32_t MEDIA_GGBG = 0x0100000a;
const int32_t MEDIA_IC_ABOUT = 0x01000014;
const int32_t MEDIA_IC_FAVORITE = 0x0100000d;
const int32_t MEDIA_IC_FEEDBACK = 0x01000008;
const int32_t MEDIA_IC_HELP = 0x01000015;
const int32_t MEDIA_LAYERED_IMAGE = 0x01000002;
const int32_t MEDIA_LBG = 0x01000033;
const int32_t MEDIA_LEFT_ARROW = 0x01000025;
const int32_t MEDIA_LOGINBACKGROUND = 0x01000031;
const int32_t MEDIA_MEBG = 0x01000035;
const int32_t MEDIA_MYBACKGROUND = 0x0100002c;
const int32_t MEDIA_NEWS1 = 0x0100000e;
const int32_t MEDIA_PLANPAGEBACKGROUND = 0x0100001f;
const int32_t MEDIA_PRIVATE = 0x01000020;
const int32_t MEDIA_QQ = 0x01000032;
const int32_t MEDIA_RECOMMEND = 0x0100002e;
const int32_t MEDIA_RECOMMENDBACKGROUND = 0x01000005;
const int32_t MEDIA_RIGHT_ARROW = 0x0100000c;
const int32_t MEDIA_ROBOT = 0x01000021;
const int32_t MEDIA_SETTING = 0x01000017;
const int32_t MEDIA_STARTICON = 0x0100002f;
const int32_t MEDIA_STUDY = 0x01000024;
const int32_t MEDIA_STUDY1 = 0x0100002b;
const int32_t MEDIA_STUDY2 = 0x0100002a;
const int32_t MEDIA_TIMBG = 0x01000009;
const int32_t MEDIA_TIMER = 0x0100001d;
const int32_t MEDIA_TU = 0x01000036;
const int32_t MEDIA_TUBIAO = 0x01000011;
const int32_t MEDIA_WECHAT = 0x01000030;
const int32_t PROFILE_BACKUP_CONFIG = 0x01000006;
const int32_t PROFILE_MAIN_PAGES = 0x01000004;
}
#endif