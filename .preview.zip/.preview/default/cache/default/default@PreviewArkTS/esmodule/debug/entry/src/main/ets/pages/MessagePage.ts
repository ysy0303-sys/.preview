if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MessagePage_Params {
    currentTab?: TabType;
    messageList?: MessageItem[];
}
import router from "@ohos:router";
type TabType = 'home' | 'plan' | 'recommend' | 'message' | 'mine';
// 1. 定义消息项接口 (必须写在组件外部，明确类型)
interface MessageItem {
    id: string;
    name: string;
    content: string;
    time: string;
    unreadCount: number;
}
class MessagePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentTab = new ObservedPropertySimplePU('message', this, "currentTab");
        this.__messageList = new ObservedPropertyObjectPU([
            { id: '1', name: '学习提醒助手', content: '周末学习打卡限时开启！最高赢学习勋章', time: '10:03', unreadCount: 4 },
            { id: '2', name: '学习福利推送官', content: '[链接]学习等级LV10速升通道限时开启', time: '03-24 09:14', unreadCount: 4 },
            { id: '3', name: '学习圈通知', content: '[链接]空降《高效学习方法》直播', time: '03-19 08:02', unreadCount: 2 },
            { id: '4', name: '学习数据中心', content: '[链接]本月学习时长统计报告已生成', time: '03-18 08:15', unreadCount: 2 },
            { id: '5', name: '学习计划官方编辑', content: '[链接]《考研英语备考计划》更新', time: '03-15 15:31', unreadCount: 4 },
            { id: '6', name: '打卡福利中心', content: '@你，有连续打卡奖励待领取！', time: '03-09 12:43', unreadCount: 0 },
            { id: '7', name: '学习周报推送', content: 'hi~你的本周学习周报已生成，点击查看', time: '02-28 13:02', unreadCount: 0 },
            { id: '8', name: '单词打卡助手', content: '[链接]【考研单词卡】新年福卡，惊喜...', time: '02-23 14:03', unreadCount: 0 }
        ], this, "messageList");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MessagePage_Params) {
        if (params.currentTab !== undefined) {
            this.currentTab = params.currentTab;
        }
        if (params.messageList !== undefined) {
            this.messageList = params.messageList;
        }
    }
    updateStateVars(params: MessagePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentTab.purgeDependencyOnElmtId(rmElmtId);
        this.__messageList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentTab.aboutToBeDeleted();
        this.__messageList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentTab: ObservedPropertySimplePU<TabType>;
    get currentTab() {
        return this.__currentTab.get();
    }
    set currentTab(newValue: TabType) {
        this.__currentTab.set(newValue);
    }
    private __messageList: ObservedPropertyObjectPU<MessageItem[]>;
    get messageList() {
        return this.__messageList.get();
    }
    set messageList(newValue: MessageItem[]) {
        this.__messageList.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MessagePage.ets(28:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.expandSafeArea([SafeAreaType.SYSTEM], [SafeAreaEdge.TOP]);
            Column.width('100%');
            Column.height('100%');
            Column.backgroundImage({ "id": 16777269, "type": 20000, params: [], "bundleName": "com.example.educationapplication", "moduleName": "entry" });
            Column.backgroundImageSize(ImageSize.Cover);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部标题栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MessagePage.ets(30:7)", "entry");
            // 顶部标题栏
            Row.width('100%');
            // 顶部标题栏
            Row.height(56);
            // 顶部标题栏
            Row.margin({ bottom: 5 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题
            Text.create("消息 ✉️");
            Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(32:9)", "entry");
            // 标题
            Text.fontSize(24);
            // 标题
            Text.fontWeight(FontWeight.Bold);
            // 标题
            Text.layoutWeight(1);
            // 标题
            Text.textAlign(TextAlign.Center);
        }, Text);
        // 标题
        Text.pop();
        // 顶部标题栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 核心滚动列表
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MessagePage.ets(42:7)", "entry");
            // 核心滚动列表
            Column.width('100%');
            // 核心滚动列表
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/MessagePage.ets(43:9)", "entry");
            Scroll.scrollable(ScrollDirection.Vertical);
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 5 });
            Column.debugLine("entry/src/main/ets/pages/MessagePage.ets(44:11)", "entry");
            Column.height(700);
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.MessageItemComponent.bind(this)(item);
            };
            this.forEachUpdateFunction(elmtId, this.messageList, forEachItemGenFunction, (item: MessageItem) => item.id, false, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
        Scroll.pop();
        // 核心滚动列表
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //底部导航
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MessagePage.ets(58:7)", "entry");
            //底部导航
            Row.width('100%');
            //底部导航
            Row.height(60);
            //底部导航
            Row.backgroundColor('#ffff');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/MessagePage.ets(59:9)", "entry");
            Column.layoutWeight(1);
            Column.onClick(() => {
                this.currentTab = 'home';
                router.pushUrl({ url: 'pages/Index' });
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("🏠");
            Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(60:11)", "entry");
            Text.fontSize(24);
            Text.fontColor(this.currentTab === 'home' ? '#2563EB' : '#6B7280');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("首页");
            Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(61:11)", "entry");
            Text.fontColor(this.currentTab === 'home' ? '#2563EB' : '#6B7280');
            Text.fontSize(14);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/MessagePage.ets(71:9)", "entry");
            Column.layoutWeight(1);
            Column.onClick(() => {
                this.currentTab = 'plan';
                router.pushUrl({ url: 'pages/GoalsPage' });
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("📝");
            Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(72:11)", "entry");
            Text.fontSize(24);
            Text.fontColor(this.currentTab === 'plan' ? '#2563EB' : '#6B7280');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("待办");
            Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(73:11)", "entry");
            Text.fontColor(this.currentTab === 'plan' ? '#2563EB' : '#6B7280');
            Text.fontSize(14);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/MessagePage.ets(83:9)", "entry");
            Column.layoutWeight(1);
            Column.onClick(() => {
                this.currentTab = 'recommend';
                router.pushUrl({ url: 'pages/recommendPage' });
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("📅");
            Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(84:11)", "entry");
            Text.fontSize(24);
            Text.fontColor(this.currentTab === 'recommend' ? '#2563EB' : '#6B7280');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("推荐");
            Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(85:11)", "entry");
            Text.fontColor(this.currentTab === 'recommend' ? '#2563EB' : '#6B7280');
            Text.fontSize(14);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/MessagePage.ets(95:9)", "entry");
            Column.layoutWeight(1);
            Column.onClick(() => { this.currentTab = 'message'; });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("✉️");
            Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(96:11)", "entry");
            Text.fontSize(24);
            Text.fontColor(this.currentTab === 'message' ? '#2563EB' : '#6B7280');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("消息");
            Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(97:11)", "entry");
            Text.fontColor(this.currentTab === 'message' ? '#2563EB' : '#6B7280');
            Text.fontSize(14);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/MessagePage.ets(104:9)", "entry");
            Column.layoutWeight(1);
            Column.onClick(() => {
                this.currentTab = 'mine';
                router.pushUrl({ url: 'pages/myPage' });
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("👤");
            Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(105:11)", "entry");
            Text.fontSize(24);
            Text.fontColor(this.currentTab === 'mine' ? '#2563EB' : '#6B7280');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("我的");
            Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(106:11)", "entry");
            Text.fontColor(this.currentTab === 'mine' ? '#2563EB' : '#6B7280');
            Text.fontSize(14);
        }, Text);
        Text.pop();
        Column.pop();
        //底部导航
        Row.pop();
        Column.pop();
    }
    MessageItemComponent(item: MessageItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MessagePage.ets(128:5)", "entry");
            Row.width('100%');
            Row.border({ width: 0, color: '#f0f0f0' });
            Row.onClick(() => {
                // 点击单条消息清空未读 (修复写法)
                if (item.unreadCount > 0) {
                    // 找到索引并更新
                    const index = this.messageList.findIndex(i => i.id === item.id);
                    if (index !== -1) {
                        this.messageList[index].unreadCount = 0;
                        // 由于是基本类型数组，直接修改索引也会触发刷新，或强制替换
                        this.messageList = [...this.messageList];
                    }
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MessagePage.ets(129:7)", "entry");
            Column.layoutWeight(1);
            Column.padding({ left: 16, right: 16, top: 12, bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 名称 + 时间
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MessagePage.ets(131:9)", "entry");
            // 名称 + 时间
            Row.width('100%');
            // 名称 + 时间
            Row.margin({ bottom: 4 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.name);
            Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(132:11)", "entry");
            Text.fontSize(17);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor('#000000');
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.time);
            Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(138:11)", "entry");
            Text.fontSize(14);
            Text.fontColor('#999999');
        }, Text);
        Text.pop();
        // 名称 + 时间
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 内容
            Text.create(item.content);
            Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(146:9)", "entry");
            // 内容
            Text.fontSize(15);
            // 内容
            Text.fontColor('#666666');
            // 内容
            Text.maxLines(1);
            // 内容
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            // 内容
            Text.width('100%');
        }, Text);
        // 内容
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 未读红点
            if (item.unreadCount > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(item.unreadCount > 99 ? '99+' : item.unreadCount.toString());
                        Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(158:9)", "entry");
                        Text.fontSize(12);
                        Text.fontColor('#ffffff');
                        Text.backgroundColor('#FF3B30');
                        Text.borderRadius(10);
                        Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                        Text.textAlign(TextAlign.Center);
                        Text.margin({ right: 16 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 占位符保持布局一致
                        Text.create("");
                        Text.debugLine("entry/src/main/ets/pages/MessagePage.ets(168:9)", "entry");
                        // 占位符保持布局一致
                        Text.width(20);
                        // 占位符保持布局一致
                        Text.margin({ right: 16 });
                    }, Text);
                    // 占位符保持布局一致
                    Text.pop();
                });
            }
        }, If);
        If.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "MessagePage";
    }
}
registerNamedRoute(() => new MessagePage(undefined, {}), "", { bundleName: "com.example.educationapplication", moduleName: "entry", pagePath: "pages/MessagePage", pageFullPath: "entry/src/main/ets/pages/MessagePage", integratedHsp: "false", moduleType: "followWithHap" });
